# Inglês de Verdade — Página de vendas do ebook

Site estático (sem build, sem dependências) da página de vendas do ebook
**“Como destravar seu inglês”**, de Davi Canal.

## Estrutura

```
.
├── index.html          # Página de vendas (leva ao checkout do Stripe)
├── obrigado.html       # Página pós-pagamento com o botão de download
├── assets/
│   ├── styles.css      # Design system (navy + dourado + creme)
│   ├── favicon.svg
│   └── cover.svg       # Capa do ebook (vetorial)
└── README.md
```

> **Imagem de compartilhamento (opcional):** o `<head>` aponta `og:image`
> para `assets/og-cover.png` (a imagem que aparece no preview do link no
> WhatsApp, Instagram, etc.). As redes sociais só mostram preview com
> imagem em PNG/JPG, então esse arquivo precisa ser adicionado à pasta
> `assets/` (arraste no GitHub ou faça `git add` a partir da sua máquina).
> Sem ele, o preview aparece só com título e descrição — a página funciona
> normalmente.

## Como funciona o fluxo de compra

1. O visitante lê a página (`index.html`) e clica em **Comprar**.
2. Vai para o checkout do Stripe:
   `https://buy.stripe.com/fZu3cv08d68G1e02d2gUM05`
3. Após pagar, o Stripe redireciona para **`obrigado.html`**, onde está o
   botão de download do PDF.

Preços exibidos: **R$ 37 · US$ 11.99 · € 9,99**.

## Configuração (2 passos)

### 1. Link de download

Abra `obrigado.html` e cole seu link em `DOWNLOAD_URL`:

```js
var DOWNLOAD_URL = "https://drive.google.com/file/d/SEU_ID/view?usp=sharing";
```

Pode ser um link de compartilhamento do **Google Drive** (é convertido
automaticamente em download direto) ou o link direto de qualquer PDF
hospedado. No Drive, deixe o arquivo como *“Qualquer pessoa com o link”*.

### 2. Redirecionamento do Stripe

No painel do Stripe, no seu **Payment Link** → *After payment* →
*Don't show confirmation page* → **Redirect customers to your website**, e
cole a URL publicada da página de obrigado, por exemplo:

```
https://SEU-DOMINIO/obrigado.html
```

## Publicar (GitHub Pages)

Este repositório já tem o GitHub Pages habilitado. Para publicar, faça o
merge desta branch na branch de origem do Pages (normalmente `main`). A URL
padrão fica:

```
https://ddacg.github.io/fluentirl/
```

> Se usar um domínio próprio, atualize as tags `og:url`, `og:image` e
> `canonical` no `<head>` do `index.html`.

## Rodar localmente

É só abrir o `index.html` no navegador. Para um servidor local:

```bash
python3 -m http.server 8000
# depois abra http://localhost:8000
```
